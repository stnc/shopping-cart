# pdo-database
easy ,basic ,simple ORM <br>
A super simple function that returns the full SQL query from your PDO statements<br>
a PDO database service provider for mysql


## 1. Installing-Connections 
```php
require_once 'vendor/autoload.php';
/*use \stnc\db as dbs;
$db = new dbs\stncmysql();*/
  define('DB_TYPE', 'mysql');
  define('DB_HOST', 'localhost');
  define('DB_NAME', 'alem');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  ```
## 2. Connections
```php

   $db = new stnc\db\stncmysql();
$tableName = 'users';
```
## 3. Select multiple rows
```php
$q = "SELECT * FROM ".$tableName;
$array_expression = $db->rows ( $q );
foreach ( $array_expression as $value ) {
	echo  $value ['name'];
	echo '<br>';
}
```
## 3. Select single row
```php
$q = "SELECT * FROM ".$tableName;
$array_expression = $db->fetch ( $q );
foreach ( $array_expression as $value ) {
	echo $value ['name'];
	echo '<br>';
}
```
## 4.  Query 
```php
$q = "ALTER TABLE users MODIFY COLUMN user_id  int(11) NOT NULL AUTO_INCREMENT FIRST";
$this->querys ( $q );
```
## 5. insert data
```php
$data = array (
		'name' => "john",
		'lastname' => "carter",
		'status' => 1,
		'age' => 25 
);


$this->insert ( $tableName, $data );
```
## 6. update metod
```php
$data = array (
		'name' => "john",
		'lastname' => "carter",
		'status' => 1,
		'age' => 25 
);
$where = array (
		'user_id' => 1 
);
$this-> update ( $tableName, $data, $where );
```
## 7. Delete metod
```php
$where = array (
		'user_id' => 1 
);
```

return $db->delete ( $tableName, $where );

## 8. last id 
```php
$db->lastID();
```
